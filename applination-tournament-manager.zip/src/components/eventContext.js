import { createContext } from 'react';

const eventContext = createContext();

export default eventContext;
