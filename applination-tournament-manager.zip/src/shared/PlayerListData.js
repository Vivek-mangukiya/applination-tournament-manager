export const PlayerListItemData=[
    {
        id: "AVP00001",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 200,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00002",
        firstName: "Jane",
        lastName: "Smith",
        points: 300,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00003",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 100,
        location: "Miami,FL",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00004",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 400,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00005",
        firstName: "Jane",
        lastName: "Smith",
        points: 600,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00006",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 500,
        location: "Miami,FL",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'

    },    
    {
        id: "AVP00007",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 900,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
        
    },
    {
        id: "AVP00008",
        firstName: "Jane",
        lastName: "Smith",
        points: 1100,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00009",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 1000,
        location: "Miami,FL",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00010",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 800,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00011",
        firstName: "Jane",
        lastName: "Smith",
        points: 1200,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00012",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 700,
        location: "Miami,FL",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00013",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 1500,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00014",
        firstName: "Jane",
        lastName: "Smith",
        points: 1300,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00015",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 140,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00016",
        firstName: "Tallah",
        lastName: "Dominic",
        points: 1900,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00017",
        firstName: "Jane",
        lastName: "Smith",
        points: 3000,
        location: "New York,NY",
        status: "Inactive",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00018",
        firstName: "Abigail",
        lastName: "Akichi",
        points: 2500,
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    }
];