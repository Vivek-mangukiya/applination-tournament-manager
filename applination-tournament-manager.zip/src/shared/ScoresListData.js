import profilepicx from '../assets/images/profilepic.jpg'

export const ScoresListItemData=[
    {
        id: "AVP00001",
        firstName: "Tallah",
        points: "6/09/2019",
        location: "Los Angeles,CA",
        status: "Open",
        image:{profilepicx}
    },
    {
        id: "AVP00002",
        firstName: "Jane",
        points: "2/04/2020",
        location: "New York,NY",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00003",
        firstName: "Abigail",
        points: "7/11/2020",
        location: "Miami,FL",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00004",
        firstName: "Tallah",
        points: "10/01/2019",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00005",
        firstName: "Jane",
        points: "10/01/2019",
        location: "New York,NY",
        status: "Closed",
        image:'../assets/images/profilepic.jpg'

    },
    {
        id: "AVP00006",
        firstName: "Abigail",
        points: "7/11/2020",
        location: "Miami,FL",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'

    },    
    {
        id: "AVP00007",
        firstName: "Tallah",
        points: "10/01/2019",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
        
    },
    {
        id: "AVP00008",
        firstName: "Jane",
        points: "6/09/2019",
        location: "New York,NY",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00009",
        firstName: "Abigail",
        points: "2/04/2020",
        location: "Miami,FL",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00010",
        firstName: "Tallah",
        points: "7/11/2020",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00011",
        firstName: "Jane",
        points: "10/01/2019",
        location: "New York,NY",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00012",
        firstName: "Abigail",
        points: "6/09/2019",
        location: "Miami,FL",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00013",
        firstName: "Tallah",
        points: "7/11/2020",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00014",
        firstName: "Jane",
        points: "7/11/2020",
        location: "New York,NY",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00015",
        firstName: "Abigail",
        points: "6/09/2019",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00016",
        firstName: "Tallah",
        points: "6/09/2019",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00017",
        firstName: "Jane",
        points: "2/04/2020",
        location: "New York,NY",
        status: "Closed",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00018",
        firstName: "Abigail",
        points: "7/11/2020",
        location: "Los Angeles,CA",
        status: "Open",
        image:'/assets/images/profilepic.jpg'
    }
];