export const RegEventTeamListData=[
    {
        id: "AVP00001",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "2000 pts",
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00018",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "500 pts",
        location: "Los Angeles,CA",
        status: "Available",
        image:'/assets/images/profilepic.jpg'
    }
];