export const RegListItemData=[
    {
        id: "AVP00001",
        firstName: "Tallah",
        lastName: "Chicago, IL",
        points: "48/48",
        location: "2/08/2020",
        status: "open",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00002",
        firstName: "Jane",
        lastName: "Honolulu, HW",
        points: "36/36",
        location: "7/11/2020",
        status: "closed",
        division:"12",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00003",
        firstName: "Abigail",
        lastName: "New York, NY",
        points: "48/48",
        location: "6/04/2019",
        status: "closed",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00004",
        firstName: "Tallah",
        lastName: "Chicago, IL",
        points: "8/48",
        location: "2/08/2020",
        status: "open",
        division:"8",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00005",
        firstName: "Jane",
        lastName: "Huntington Beach, CA",
        points: "36/36",
        location: "7/11/2020",
        status: "closed",
        division:"12",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00006",
        firstName: "Abigail",
        lastName: "Honolulu, HW",
        points: "8/48",
        location: "6/04/2019",
        status: "closed",
        division:"4",
        image:'/assets/images/profilepic.jpg'

    },    
    {
        id: "AVP00007",
        firstName: "Tallah",
        lastName: "Chicago, IL",
        points: "48/48",
        location: "2/08/2020",
        status: "Full",
        division:"8",
        image:'/assets/images/profilepic.jpg'
        
    },
    {
        id: "AVP00008",
        firstName: "Jane",
        lastName: "Huntington Beach, CA",
        points: "8/48",
        location: "6/04/2019",
        status: "closed",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00009",
        firstName: "Abigail",
        lastName: "New York, NY",
        points: "36/36",
        location: "2/08/2020",
        status: "closed",
        division:"12",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00010",
        firstName: "Tallah",
        lastName: "Chicago, IL",
        points: "8/48",
        location: "7/11/2020",
        status: "Full",
        division:"12",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00011",
        firstName: "Jane",
        lastName: "Honolulu, HW",
        points: "48/48",
        location: "6/04/2019",
        status: "closed",
        division:"8",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00012",
        firstName: "Abigail",
        lastName: "New York, NY",
        points: "8/48",
        location: "2/08/2020",
        status: "Full",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00013",
        firstName: "Tallah",
        lastName: "Huntington Beach, CA",
        points: "36/36",
        location: "6/04/2019",
        status: "open",
        division:"12",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00014",
        firstName: "Jane",
        lastName: "Chicago, IL",
        points: "8/48",
        location: "6/04/2019",
        status: "closed",
        division:"12",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00015",
        firstName: "Abigail",
        lastName: "Honolulu, HW",
        points: "8/48",
        location: "7/11/2020",
        status: "open",
        division:"8",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00016",
        firstName: "Tallah",
        lastName: "New York, NY",
        points: "48/48",
        location: "2/08/2020",
        status: "open",
        division:"8",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00017",
        firstName: "Jane",
        lastName: "Chicago, IL",
        points: "36/36",
        location: "6/04/2019",
        status: "closed",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00018",
        firstName: "Abigail",
        lastName: "Chicago, IL",
        points: "48/48",
        location: "7/11/2020",
        status: "open",
        division:"4",
        image:'/assets/images/profilepic.jpg'
    }
];