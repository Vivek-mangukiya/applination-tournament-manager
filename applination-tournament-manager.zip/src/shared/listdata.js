export const ListItemData=[
    {
        id: "AVP00001",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00002",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00003",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "abigailakichi@gmail.com",
        location: "Miami,FL",
        status: "Inactive",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00004",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00005",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'

    },
    {
        id: "AVP00006",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "abigailakichi@gmail.com",
        location: "Miami,FL",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'

    },    
    {
        id: "AVP00007",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
        
    },
    {
        id: "AVP00008",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00009",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "abigailakichi@gmail.com",
        location: "Miami,FL",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00010",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00011",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00012",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "abigailakichi@gmail.com",
        location: "Miami,FL",
        status: "Inactive",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00013",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00014",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00015",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00016",
        firstName: "Tallah",
        lastName: "Dominic",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00017",
        firstName: "Jane",
        lastName: "Smith",
        email: "janesmith@gmail.com",
        location: "New York,NY",
        status: "Inactive",
        points: "15/10/20",
        image:'/assets/images/profilepic.jpg'
    },
    {
        id: "AVP00018",
        firstName: "Abigail",
        lastName: "Akichi",
        email: "tallahdominic@gmail.com",
        location: "Los Angeles,CA",
        status: "Available",
        points:"11/9/15",
        image:'/assets/images/profilepic.jpg'
    }
];