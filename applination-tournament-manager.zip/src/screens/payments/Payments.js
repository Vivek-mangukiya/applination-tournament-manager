import React from 'react';
import './Payments.css';

const Payments = () => {
  return (
    <div className="new-event-profile container p-0">
      <div className="row" style={{ marginTop: 142 }}>
        <div className="col-6 m-auto text-center">
          <div className="row text-center">Payments</div>
        </div>
      </div>
    </div>
  );
};

export default Payments;
