import { createContext } from 'react';

const templateDivisionContext = createContext();

export default templateDivisionContext;
