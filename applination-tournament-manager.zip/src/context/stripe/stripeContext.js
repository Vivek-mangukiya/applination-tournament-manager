import { createContext } from 'react';

const stripeContext = createContext();

export default stripeContext;