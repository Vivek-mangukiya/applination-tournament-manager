import { createContext } from 'react';

const playerProfileContext = createContext();

export default playerProfileContext;
