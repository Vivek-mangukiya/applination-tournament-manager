import { createContext } from 'react';

const activeHistoryContext = createContext();

export default activeHistoryContext;
