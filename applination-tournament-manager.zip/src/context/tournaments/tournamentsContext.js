import { createContext } from "react";

const tournamentsContext = createContext();

export default tournamentsContext;
