import { createContext } from 'react';

const templatePoolsContext = createContext();

export default templatePoolsContext;
