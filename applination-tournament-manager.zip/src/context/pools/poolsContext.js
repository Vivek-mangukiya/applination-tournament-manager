import { createContext } from 'react';

const poolsContext = createContext();

export default poolsContext;
