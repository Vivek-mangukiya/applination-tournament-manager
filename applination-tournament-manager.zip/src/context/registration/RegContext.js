import { createContext } from 'react';

const RegContext = createContext();

export default RegContext;