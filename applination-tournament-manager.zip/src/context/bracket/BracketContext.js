import { createContext } from 'react';

const BracketContext = createContext();

export default BracketContext;