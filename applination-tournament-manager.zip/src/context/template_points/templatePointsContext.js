import { createContext } from 'react';

const templatePointsContext = createContext();

export default templatePointsContext;
