import { createContext } from 'react';

const templateListContext = createContext();

export default templateListContext;
