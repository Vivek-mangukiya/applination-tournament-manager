import { createContext } from 'react';

const ScoresContext = createContext();

export default ScoresContext;
