import { createContext } from 'react';

const newManagerProfileContext = createContext();

export default newManagerProfileContext;
